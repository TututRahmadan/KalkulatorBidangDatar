package com.bidangdatar.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.widget.Button;
public class MainActivity extends AppCompatActivity {
Button btPersegi; Button btsegitiga; Button btlingkaran;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btPersegi=(Button) findViewById(R.id.persegi);
        btsegitiga=(Button) findViewById(R.id.segi3);
        btlingkaran=(Button) findViewById(R.id.lingBut);
        btPersegi.setOnClickListener(v -> openPersegi());
        btsegitiga.setOnClickListener(v -> openSegitiga());
        btlingkaran.setOnClickListener(v -> openLingkaran());
    }
    public void openPersegi() {
        Intent intent = new Intent(this, Persegi.class);
        startActivity(intent);
    }
    public void openSegitiga(){
        Intent intent = new Intent(this, Segitiga.class);
        startActivity(intent);
    }
    public void openLingkaran(){
        Intent intent = new Intent(this, Lingkaran.class);
        startActivity(intent);
    }
}