package com.bidangdatar.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class Persegi extends AppCompatActivity {
    private EditText txtSisi;
    private EditText txtLuas;
    private EditText txtKeliling;
    private Button btnHitung;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_persegi);
        txtSisi=(EditText) findViewById(R.id.txtSisi);
        txtLuas=(EditText) findViewById(R.id.txtLuas);
        txtKeliling=(EditText) findViewById(R.id.txtKeliling);
        btnHitung=(Button) findViewById(R.id.btnHitung);
    }
    public void hitungLuasPersegi(View view) {
        try {
            double sisi = Integer.parseInt(txtSisi.getText().toString());
            double luas;
            luas = sisi*sisi;
            double keliling=sisi*4;
            txtLuas.setText(String.valueOf(luas));
            txtKeliling.setText(String.valueOf(keliling));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void backtoMenu(View view){
        finish();
    }
}