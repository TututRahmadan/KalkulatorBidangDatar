package com.bidangdatar.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Segitiga extends AppCompatActivity {
    private EditText txtAlas;
    private EditText txtTinggi;
    private EditText txtLuas;
    private EditText txtKeliling;
    private Button btnHitung;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segitiga);
        txtAlas=(EditText) findViewById(R.id.txtAlas);
        txtTinggi=(EditText) findViewById(R.id.txtTinggi);
        txtLuas=(EditText) findViewById(R.id.txtLuas);
        txtKeliling=(EditText) findViewById(R.id.txtKeliling);
        btnHitung=(Button) findViewById(R.id.btnHitung);
    }
    public void hitungLuasSegitiga(View view) {
        try {
            double alas = Integer.parseInt(txtAlas.getText().toString());
            double tinggi = Integer.parseInt(txtTinggi.getText().toString());
            double luas = (alas*tinggi)/2;
            double c=Math.pow(alas,2)+Math.pow(tinggi,2);
            double keliling=Math.sqrt(c)*2+alas;
            txtLuas.setText(String.valueOf(luas));
            txtKeliling.setText(String.valueOf(keliling));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void backtoMenu(View view){
        finish();
    }
}