package com.bidangdatar.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Lingkaran extends AppCompatActivity {
    private EditText txtDiameter;
    private EditText txtLuas;
    private EditText txtKeliling;
    private Button btnHitung;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lingkaran);
        txtDiameter=(EditText) findViewById(R.id.txtDiameter);
        txtLuas=(EditText) findViewById(R.id.txtLuas);
        txtKeliling=(EditText) findViewById(R.id.txtKeliling);
        btnHitung=(Button) findViewById(R.id.btnHitung);
    }
    public void hitungLuasLingkaran(View view) {
        try {
            double diameter = Integer.parseInt(txtDiameter.getText().toString());
            double phi = 3.14;
            double r = diameter/2;
            double luas=r*r*phi;
            double keliling=phi*diameter;
            txtLuas.setText(String.valueOf(luas));
            txtKeliling.setText(String.valueOf(keliling));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void backtoMenu(View view){
        finish();
    }
}